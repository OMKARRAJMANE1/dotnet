namespace productcrud.Controllers;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using productcrud.Entities;
using productcrud.Models;
using productcrud.Services;

public class ProductController:Controller{
    private readonly IProductService _svc;

    public ProductController(IProductService _svc){
        Console.WriteLine("inside ctor of ProductService");
        this._svc=_svc;
    }

    [HttpGet]
    public IActionResult Index(){
        List<Product> products=_svc.GetAllProd();
        TempData["proddata"]=products;
        return View();
    }

    public IActionResult List(){
        List<Product> products=_svc.GetAllProd();
        return View(products);
    }

    public IActionResult Details(int id){
        Product product=_svc.GetById(id);
        return View(product);
    }

    public IActionResult Delete(int id){
        _svc.Delete(id);
        return RedirectToAction("Index","Product",null);
    }

    [HttpGet]
    public IActionResult Insert(){
        return View();
    }

    public IActionResult Insert(IFormCollection form){
        Product prod=new Product{Id=int.Parse(form["id"]),Name=form["name"],Price=float.Parse(form["price"]),Quantity=int.Parse(form["qty"])};
        _svc.Insert(prod);
        return RedirectToAction("Index","Product",null);
    }

    
}