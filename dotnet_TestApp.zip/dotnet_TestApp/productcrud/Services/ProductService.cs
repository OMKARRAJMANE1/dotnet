using productcrud.Entities;
using productcrud.Repository;

namespace productcrud.Services;

public class ProductService:IProductService{
    
    public List<Product> GetAllProd(){
        List<Product> products=new List<Product>();
        MySqlDBManager mgr=new MySqlDBManager();
        products=mgr.GetAllProd();
        return products;
    }

    public Product GetById(int id){
        MySqlDBManager mgr =new MySqlDBManager();
        Product product=mgr.GetById(id);
        return product;
    }

    public void Delete(int id){
        MySqlDBManager mrg =new MySqlDBManager();
        mrg.Delete(id);
        
    }

    public void Insert(Product prod){
        MySqlDBManager mrg =new MySqlDBManager();
        mrg.Insert(prod);
        
    }


}