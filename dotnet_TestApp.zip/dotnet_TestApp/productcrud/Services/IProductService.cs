using productcrud.Entities;

namespace productcrud.Services;

public interface IProductService{
    public List<Product> GetAllProd();
    public Product GetById(int id);
    public void Delete(int id);
    public void Insert(Product prod);
}